class BreakContinueEx
{
public static void main(String args[]){
	for (int i = 0; i < 5; i++)    //Outer loop
{
	if(i == 3)
	{
		break;
	}

	for(int j = 0; j < 5; j++)	//Inner loop
	{
		if(j == 3)
		{
		        break;
		}
		else
		{
		        System.out.print(j+ "  ");
		}
	}
	System.out.println();
	System.out.println("Out of inner for loop");
}
System.out.println("Out of outer for loop");
}
}
