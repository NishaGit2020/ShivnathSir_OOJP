class Test
{
	int a;
	int b;
	Test(int a, int b)
	{
		a = a;
		b = b;
		System.out.println("Inside constructor : "+a);
		System.out.println("Inside constructor : "+b);
	}
	void print()
	{
		System.out.println(a);
		System.out.println(b);
	}

	public static void main(String args[])
	{
		Test t = new Test(5,10);
		t.print();
	}

}
