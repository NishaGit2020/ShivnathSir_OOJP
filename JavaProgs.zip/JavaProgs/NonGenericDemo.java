class MyNonGen 
{
	Object ob;

	MyNonGen(Object s)
	{
		this.ob = s;
	}

	void printOb()
	{
		System.out.println(ob);
	}

	Object getOb()
	{
		return ob;
	}
}

class NonGenericDemo
{
	public static void main(String args[])
	{
		MyNonGen strOb = new MyNonGen("Welcome");
		strOb.printOb();
		String s = (String)strOb.getOb();		//String = Object
		System.out.println(s);
		
		MyNonGen intOb = new MyNonGen (100);
		intOb.printOb();
		Integer i = (Integer) intOb.getOb();		//Integer = Object
		System.out.println(i);

		intOb = strOb;
		i = (Integer) intOb.getOb();
		
	}
}
