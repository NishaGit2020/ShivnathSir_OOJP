import java.util.*;
class ArrayListDemo
{
	public static  void display(Collection<String> c)
	{
		for(String elem: c)
		{
			System.out.println(elem);
		}
	}
	public static void main(String args[])
	{
		//Purpose is to store name of students.
		
		ArrayList <String> arList = new ArrayList <String> ();
		//String name1 = "Ram";
		//arList.add(name1);
		arList.add("Ram");
		arList.add("Shyam");
		arList.add("Sita");
		arList.add("Gita");
		arList.add("Rohit");

		arList.add(2,"Mukesh");

		display(arList);
		String s = arList.get(1);
		System.out.println("Value at index 1 : "+s);

		int indx = arList.indexOf("Gita");
		System.out.println("Index of Gita: "+ indx);

		//arList.remove(1);
		//arList.remove("Ram");
		arList.set(2,"Alex");

		System.out.println("Print using list iterator");
		ListIterator <String> lt = arList.listIterator();
		while(lt.hasNext())
		{
			String st = lt.next();
			if(st.equals("Rohit"))
			{
				lt.remove();
			}
			System.out.println(st);
		}

		System.out.println("Printing sublist");
		List<String> subList = arList.subList(1,4);
		display(subList);
		

	}
}


