class JaggedArray
{
	public static void main(String args[])
	{
		int jaggedArr [][] = new int[3][];
		jaggedArr[0] = new int[1];
	}
}
