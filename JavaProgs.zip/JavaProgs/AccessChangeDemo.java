class First
{
	protected int a;
	protected void fun()
	{
	}
}

class Second extends First
{
	int a;
	public void fun()
	{
	}
}

class AccessChangeDemo
{
	public static void main(String args[])
	{
	}
}
