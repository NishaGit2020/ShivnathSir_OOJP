class WrapperDemo
{
	public static void main(String args[])
	{
		Double dOb1 = new Double("43.5");
Double dOb2 = new Double("23.5");

int res = dOb1.compareTo(dOb2);  // if returns zero, means both are same
System.out.println(res) ; // prints 0

		Integer iOb1 = new Integer (50);
		System.out.println(dOb1.toString());
		String dStr = dOb1.toString();  // "43.5"
		dStr = dStr * 15;
		System.out.println(dStr);
		iOb1 = (Integer)dOb1;
	}
}
