class Demo
{
	final int a = 10;

	final Demo()
	{
	}

	void fun()
	{
		//a = 10;	//Error
		final int b;   //Value yet not initialized
		b = 15;		//Work
		//b = 20;	//Error
	}
}

final class Test extends Demo
{
	final void fun()
	{
		System.out.println("Overriding method fun");
	}
}

class FinalDemo 
{
	public static void main(String args[])
	{
		Demo d = new Demo();
		d.fun();
	}
}
