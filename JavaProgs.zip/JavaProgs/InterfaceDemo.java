interface MyInterface
{
	int MIN = 10;		//public, static, final
	int MAX = 100;

	void fun();		//public, abstract
	void anotherFun();
}

class MyTest implements MyInterface		//MyTest is an implementing class
{
	//If class MyTest does not implements all the methods of MyInterface then this class 
	//MyTest will become an abstract class.

	public void fun()
	{
		System.out.println("fun of MyTest");
	}

	public void anotherFun()
	{
		System.out.println("anotherFun of MyTest");
	}

	void diffFun()
	{
		System.out.println("diffFun of MyTest");
	}

	public void fun2()
	{
		System.out.println("implemented fun2");
	}


}

class InterfaceDemo
{
	public static void main(String args[])
	{
	//new MyInterface() ; //Wrong, we can not create any object or instantiate any interface
		MyInterface mif;
		mif = new MyTest();
		mif.fun();		//OK
		mif.anotherFun();	//OK
		//mif.diffFun();		//Error	
	}
}
