class First
{
}
class Second extends First
{
}

class InstanceOfDemo
{
	public static void main(String args[])
	{
		First f = new First();
		Second s = new Second();

		if (f instanceof Second)
		{
			System.out.println("f is an instance of Second");
		}
		else
		{
			System.out.println("f is not an instance of Second");
		}

		if (s instanceof First)
		{
			System.out.println("s is an instance of First");
		}
		else
		{
			System.out.println("s is not an instance of First");
		}

		if (s instanceof Second)
		{
			System.out.println("s is an instance of Second");
		}
		else
		{
			System.out.println("s is not an instance of Second");
		}

		System.out.println("f is an object of class : "+f.getClass().getName());
		System.out.println("s is an object of class : "+s.getClass().getName());
		
	}
}
