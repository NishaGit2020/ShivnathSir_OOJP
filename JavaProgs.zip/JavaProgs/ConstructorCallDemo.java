class First
{
	int a;

	First()
	{
		System.out.println("First Constructor");
	}
}

class Second extends First
{
	int b;

	Second()
	{
		System.out.println("Second Constructor");
	}
}

class Third extends Second
{
	int c;

	Third()
	{
		System.out.println("Third Constructor");
	}
}

class ConstructorCallDemo
{
	public static void main(String args[])
	{
		new Third();
	}
}









