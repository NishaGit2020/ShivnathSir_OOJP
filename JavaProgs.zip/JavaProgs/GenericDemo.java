class Demo
{
	int a;

	Demo(int a)
	{
		this.a = a;
	}

	public String toString()
	{
		return "Demo [a = " +a +"]";
	}
}

class Gen <T>
{
	
	T ob;

	Gen(T obj)
	{
		this.ob = obj;
	}

	<T2> void fun(T obj, T2 obj2)
	{
		System.out.println(obj);
		System.out.println(obj2);
	}
}

class GenericDemo
{
	public static void main(String args[])
	{
		Gen<Integer> intOb = new Gen<Integer> (100);

		Demo d = new Demo(10);
		intOb.fun(200.5,d);
	}
}
