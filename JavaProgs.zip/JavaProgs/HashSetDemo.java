import java.util.*;
class HashSetDemo
{
	public static void display(Collection<String> c)
	{
		for(String elem: c)
		{
			System.out.println(elem);
		}
	}
	public static void main(String args[])
	{
		//Purpose is to store name of students.
		
		HashSet <String> hs = new HashSet <String> ();
		//String name1 = "Ram";
		//hs.add(name1);
		hs.add("Ram");
		hs.add("Shyam");
		hs.add("Sita");
		hs.add("Gita");
		hs.add("Mohan");
		
		//Using for-each to iterate through these elements

		for(String s : hs)
		{
			System.out.println(s);
		}

		HashSet <String> hs1 = new HashSet <String> ();
		hs1.add("Rohit");
		hs1.add("Mukesh");

		hs.addAll(hs1);

		System.out.println("After adding hs1 to hs");
		for(String s : hs)
		{
			System.out.println(s);
		}

		if(hs.contains("Shyaam"))
		{
			System.out.println("Shyam is present there");
		}

		if(hs.containsAll(hs1))
		{
			System.out.println("hs contains all objects from hs1");
		}

		System.out.println("Iterating through container objects using Iterator:");
		Iterator <String> it = hs.iterator();

		while(it.hasNext())
		{
			String s = it.next();
			System.out.println(s);
		}

		//Removing element
		hs.remove("Shyam");
		System.out.println("After removing Shyam");
		display(hs);

		//Removing a subset
		hs.removeAll(hs1);
		System.out.println("After removing all elements of hs1 from hs:");
		display(hs);

		System.out.println("Total Elements: "+hs.size());
		System.out.println("Printing elements using toArray() method:");
		Object [] arr = hs.toArray();
		for(Object obj : arr)
		{
			System.out.println(obj);
		}

		System.out.println("Printing elements using toArray(strArr) method:");
		String strArr[] = new String[hs.size()];
		strArr = hs.toArray(strArr);
		for(String s : strArr)
		{
			System.out.println(s);
		}

	}
}

