import java.util.*;
class TreeSetDemo
{
	public static void display(Collection<String> c)
	{
		for(String elem: c)
		{
			System.out.println(elem);
		}
	}
	public static void main(String args[])
	{
		//Purpose is to store name of students.
		
		TreeSet <String> ts = new TreeSet <String> ();
		//String name1 = "Ram";
		//ts.add(name1);
		ts.add("Ram");
		ts.add("Shyam");
		ts.add("Sita");
		ts.add("Gita");
		ts.add("Mohan");
		
		//Using for-each to iterate through these elements

		for(String s : ts)
		{
			System.out.println(s);
		}

		TreeSet <String> ts1 = new TreeSet <String> ();
		ts1.add("Rohit");
		ts1.add("Mukesh");

		ts.addAll(ts1);

		System.out.println("After adding ts1 to ts");
		for(String s : ts)
		{
			System.out.println(s);
		}

		if(ts.contains("Shyaam"))
		{
			System.out.println("Shyam is present there");
		}

		if(ts.containsAll(ts1))
		{
			System.out.println("ts contains all objects from ts1");
		}

		System.out.println("Iterating through container objects using Iterator:");
		Iterator <String> it = ts.iterator();

		while(it.hasNext())
		{
			String s = it.next();
			System.out.println(s);
		}

		//Removing element
		ts.remove("Shyam");
		System.out.println("After removing Shyam");
		display(ts);

		//Removing a subset
		ts.removeAll(ts1);
		System.out.println("After removing all elements of ts1 from ts:");
		display(ts);

		System.out.println("Total Elements: "+ts.size());
		System.out.println("Printing elements using toArray() method:");
		Object [] arr = ts.toArray();
		for(Object obj : arr)
		{
			System.out.println(obj);
		}

		System.out.println("Printing elements using toArray(strArr) method:");
		String strArr[] = new String[ts.size()];
		strArr = ts.toArray(strArr);
		for(String s : strArr)
		{
			System.out.println(s);
		}

		System.out.println("Frist element: "+ts.first());

	}
}

