import java.util.*;
class HashMapSortTestDemo
{
	public static void main(String args[])
	{
		TreeMap<String,String> hm = new TreeMap<String,String>();

		hm.put("abc","Gita");
		hm.put("aad","Shyam");
		hm.put("dab","Ram");
		hm.put("cad","Sita");
		hm.put("eaf","Rohit");

		Set<Map.Entry<String,String>> entSet = hm.entrySet();

		System.out.println("Display using for-each: ");
		for(Map.Entry<String,String> entry : entSet)
		{
			System.out.println(entry.getKey()+ " " + entry.getValue());
			if(entry.getValue().equals("Rohit"))
			{
				entry.setValue("Mohit");
			}
		}


	}
}
