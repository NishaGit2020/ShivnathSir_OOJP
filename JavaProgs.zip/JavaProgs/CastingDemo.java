class First
{
	void fun()
	{
		System.out.println("fun of First");
	}
	void fun1()
	{
		System.out.println("fun1 of First");
	}
}

class Second extends First
{
	void fun()
	{
		System.out.println("fun of Second");
	}

	void fun2()
	{
		System.out.println("fun2 of Second");
	}
	
}


class Third
{
	void fun()
	{
		System.out.println("fun of Third");
	}
}

class CastingDemo
{
	public static void main(String args[])
	{

		First f;
		Second s;

		//f = new First();
		//s = (Second)f;		//child = parent; Here explicit casting is must
				// Error at runtime because f contains reference of object of First
		

		f = new Second();		//Parent = child	
		s = (Second)f; //Works, beacuase at runtime f contains reference of object of Second
		s.fun();
		s.fun1();
		s.fun2();
		((Second)f).fun2();

	}
}
