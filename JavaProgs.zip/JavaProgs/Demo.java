class First
{
	void fun()
	{
		System.out.println("fun of First");
	}
	
	protected void finalize()
	{
		System.out.println("finalize method of First");
	}
	
}
class Demo
{
	public static void main(String args[])
	{
		First f = new First();
		f.fun();
		f = null;
		//System.gc();
		 Runtime.getRuntime().gc();
	}
}
