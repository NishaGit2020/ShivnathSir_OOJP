class StringBufferDemo
{
	public static void main(String args[])
	{
		StringBuffer str1 = new StringBuffer("Welcome");
		System.out.println(str1);
		System.out.println(str1.capacity());
	}
}
