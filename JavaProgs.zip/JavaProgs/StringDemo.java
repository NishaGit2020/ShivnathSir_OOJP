class StringDemo
{
	public static void main(String args[])
	{
		String str1 = new String("Welcome");
		System.out.println(str1);
		str1 = str1.concat(" Friends");
		System.out.println(str1);
	}
}
