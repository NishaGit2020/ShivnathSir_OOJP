class MyException extends RuntimeException  
{
	String excpMsg;

	MyException()
	{
	}

	MyException(String excpMsg)   //excpMsg = "This is my exception message"
	{
		super(excpMsg);
		this.excpMsg = excpMsg;
	}

	public String getMessage()
	{
		
		return "MyException: "+excpMsg;
	}

	public String toString()
	{
		return "MyException generated";
	}
}

class ExceptionDemo
{
	public static void main(String args[])
	{
		int age = 16;

		if(age < 18)
		{
			MyException myExpObj = new MyException("Age can not be less than 18!");
			throw myExpObj;
		}
		else
		{
			System.out.println("Vote Id card created");
		}
		
	}
}
