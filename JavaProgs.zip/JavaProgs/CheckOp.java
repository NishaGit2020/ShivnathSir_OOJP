class CheckOp
{
	public static void main(String args[])
	{
		int i = -258;
		byte b;
		b = (byte) i;
		System.out.println(b);

		char ch = '\u0041';  //Hexa
		ch = '\101';
		ch = 'A';
		System.out.println(ch);

		b = (byte)258;
		//b = b * 2;
		System.out.println(b);

		int a = 50;
		b = (byte)a;

		b = (byte)(b * (byte)2);

		a = 5;
		int res = a << 2;
		System.out.println(res);
	}
}
