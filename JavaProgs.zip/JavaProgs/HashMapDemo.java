import java.util.*;
class HashMapDemo
{
	public static void main(String args[])
	{
		HashMap<Integer,String> hm = new HashMap<Integer,String>();

		hm.put(4,"Gita");
		hm.put(2,"Shyam");
		hm.put(1,"Ram");
		hm.put(3,"Sita");
		hm.put(5,"Rohit");

		Set<Map.Entry<Integer,String>> entSet = hm.entrySet();

		System.out.println("Display using for-each: ");
		for(Map.Entry<Integer,String> entry : entSet)
		{
			System.out.println(entry.getKey()+ " " + entry.getValue());
			if(entry.getValue().equals("Rohit"))
			{
				entry.setValue("Mohit");
			}
		}

		System.out.println("Display using iterator: ");
		Iterator<Map.Entry<Integer,String>> it = entSet.iterator();
		while(it.hasNext())
		{
			Map.Entry<Integer,String> entry = it.next();
			System.out.println(entry.getKey()+ " " + entry.getValue());
		}

		hm.put(3,"Geeta");
		hm.remove(2);
		System.out.println("After updating value Gita to Geeta");
		it = entSet.iterator();
		while(it.hasNext())
		{
			Map.Entry<Integer,String> entry = it.next();
			System.out.println(entry.getKey()+ " " + entry.getValue());
		}

		System.out.println("Value for key 2 is : "+hm.get(2));

		System.out.println("Displaying using keyset:");
		Set<Integer> kSet = hm.keySet();
		for(Integer key : kSet)
		{
			System.out.println(key + " " + hm.get(key));
		}


	}
}
