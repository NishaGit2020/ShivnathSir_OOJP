class First
{
	int a;
	
	
	First(int a)
	{
		this.a = a;
	}

	public int hashCode()
	{
		return a;
	}

	boolean equals(First f)
	{
		if(this.a == f.a)
			return true;
		else
			return false;
	}

	public String toString()
	{
		return "First [a = " + a + "]";
	}
}

class ObjectComparision
{
	public static void main(String args[])
	{
		First f1 = new First(5);
		First f2 = new First(5);
		First f3 = f1;
		

		if (f1.equals(f2))
		{
			System.out.println("f1 equals f2");
		}
		else
		{
			System.out.println(" f1 not equals f2");
		}


		if (f1.equals(f3))
		{
			System.out.println(" f1 equals f3");
		}
		else
		{
			System.out.println(" f1 not equals f3");
		}

		if(f1 == f2)		//References are compared
		{
			System.out.println("f1 == f2");
		}
		else
		{
			System.out.println("f1 != f2");
		}

		System.out.println(f1.hashCode());
		System.out.println(f2.hashCode());
		System.out.println(f3.hashCode());

		System.out.println(f1);	
		
	}
}
