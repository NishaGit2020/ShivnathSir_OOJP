class Cricketer
{
	String name;
	String country;
	int totalMatches;

	int num;
	
	Cricketer()
	{
		System.out.println("Zero argument constructor of Cricketer class");
	}

	Cricketer(String name, String country, int totalMatches)
	{
		System.out.println("Three argument constructor of Cricketer class");
		this.name = name;
		this.country = country;
		this.totalMatches = totalMatches;
	}

	void displayName()
	{
		System.out.println(name);
	}

	void displayCountry()
	{
		System.out.println(country);
	}

	void displayTotalMatches()
	{
		System.out.println(totalMatches);
	}

	void displayAllDetails()
	{
		System.out.println(name);
		System.out.println(country);
		System.out.println(totalMatches);
	}
	
}


class Batsman extends Cricketer
{
	int totalRuns;
	int num;

	Batsman(String n, String c, int tm, int tr)
	{
		super(n,c,tm);
		System.out.println("Four argument constructor of Batsman class");
		this.totalRuns = tr;
		num = 10;
		super.num = 20;
	}

	void displayTotalRun()
	{
		//super();		//Will give error
		System.out.println(totalRuns);
	}

	void displayAllDetails()			//Example of method overriding
	{
		//super.displayName();
		super.displayAllDetails();		//Calls superclass displayAllDetails()
		System.out.println(totalRuns);
		System.out.println(super.num);
	}
}

class Bowler extends Cricketer
{
	int totalWickets;

	Bowler(String n, String c, int tm, int tw)
	{
		//super(n,c,tm);
		System.out.println("Four argument constructor of Bowler class");
		this.totalWickets = tw;
	}

	void displayTotalWickets()
	{
		System.out.println(totalWickets);
	}
}

class InheritanceDemo
{
	public static void main(String args[])
	{

		Batsman bat = new Batsman("Sachin Tendulkar","India",463,18000);
		System.out.println(bat);
		System.out.println(bat.hashCode());
		
	}
}
























